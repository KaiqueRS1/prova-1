﻿using System;

public class ContaCorrente : Conta
{
    public ContaCorrente(Cliente titular, long numero, decimal depositoInicial = 0.00M)
        : base(titular, numero, depositoInicial)
    {
    }

    public override string ToString()
    {
        return $"ContaCorrente {base.ToString()}";
    }
}
