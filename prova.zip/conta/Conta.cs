﻿using System;

public abstract class Conta
{
    private const decimal TAXA_SAQUE = 0.10M;

    public long Numero { get; private set; }
    public decimal Saldo { get; protected set; }
    public Cliente Titular { get; private set; }

    public Conta(Cliente titular, long numero, decimal depositoInicial = 0.00M)
    {
        if (numero <= 999)
        {
            throw new ArgumentException("O número da conta deve ser superior a 999.");
        }

        Titular = titular;
        Numero = numero;

        if (depositoInicial <= 0)
        {
            Saldo = 10.00M;
        }
        else
        {
            Saldo = depositoInicial;
        }
    }

    public void Depositar(decimal valor)
    {
        if (valor > 0)
        {
            Saldo += valor;
            Console.WriteLine($"Depósito de R$ {valor:F2} realizado na conta {Numero}");
        }
        else
        {
            Console.WriteLine("O valor do depósito deve ser positivo.");
        }
    }

    public virtual bool Sacar(decimal valor)
    {
        decimal valorTotal = valor + TAXA_SAQUE;

        if (Saldo >= valorTotal)
        {
            Saldo -= valorTotal;
            Console.WriteLine($"Saque de R$ {valor:F2} (taxa: R$ {TAXA_SAQUE:F2}) realizado na conta {Numero}");
            return true;
        }
        else
        {
            Console.WriteLine($"Saque negado na conta {Numero}: Saldo insuficiente (R$ {Saldo:F2}). Valor + Taxa: R$ {valorTotal:F2}");
            return false;
        }
    }

    public bool Transferir(Conta destino, decimal valor)
    {
        if (Sacar(valor))
        {
            destino.Depositar(valor);
            Console.WriteLine($"Transferência de R$ {valor:F2} da conta {Numero} para a conta {destino.Numero} realizada.");
            return true;
        }
        else
        {
            Console.WriteLine($"Transferência negada por saldo insuficiente na conta {Numero}");
            return false;
        }
    }

    public override string ToString()
    {
        return $"[Numero={Numero}, Saldo={Saldo:F2}, Titular={Titular.Nome}]";
    }
}