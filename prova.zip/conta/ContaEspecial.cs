﻿using System;

public class ContaEspecial : Conta
{
    private const decimal TAXA_SAQUE = 0.10M;

    public decimal Limite { get; private set; }

    public ContaEspecial(Cliente titular, long numero, decimal limite, decimal depositoInicial = 0.00M)
        : base(titular, numero, depositoInicial)
    {
        Limite = limite;
    }

    public override bool Sacar(decimal valor)
    {
        decimal valorTotal = valor + TAXA_SAQUE;

        decimal saldoDisponivel = Saldo + Limite;

        if (saldoDisponivel >= valorTotal)
        {
            Saldo -= valorTotal;
            Console.WriteLine($"Saque de R$ {valor:F2} (taxa: R$ {TAXA_SAQUE:F2}) realizado na Conta Especial {Numero}");
            return true;
        }
        else
        {
            Console.WriteLine($"Saque negado na Conta Especial {Numero}: Saldo + Limite insuficiente (R$ {saldoDisponivel:F2}). Valor + Taxa: R$ {valorTotal:F2}");
            return false;
        }
    }

    public override string ToString()
    {
        return $"ContaEspecial [Numero={Numero}, Saldo={Saldo:F2}, Limite={Limite:F2}, Titular={Titular.Nome}]";
    }
}