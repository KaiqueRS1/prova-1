﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Agencia
{
    private List<Conta> _contas;

    public Agencia()
    {
        _contas = new List<Conta>();
    }

    public void InserirConta(Conta conta)
    {
        if (_contas.Any(c => c.Numero == conta.Numero))
        {
            Console.WriteLine($"Erro: Conta {conta.Numero} já cadastrada.");
        }
        else
        {
            _contas.Add(conta);
            Console.WriteLine($"Conta {conta.Numero} cadastrada com sucesso na Agência.");
        }
    }

    public decimal CalcularTotal()
    {
        return _contas.Sum(conta => conta.Saldo);
    }

    public IReadOnlyList<Conta> Contas => _contas;
}   