﻿using System;
using System.Globalization;
using System.Linq;
using System.Collections.Generic;

public class Program
{
    private static Agencia agencia = new Agencia();

    public static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.WriteLine("--- Sistema Interativo de Controle de Contas ---");

        bool sair = false;
        while (!sair)
        {
            Console.WriteLine("\n--------------------------------------------------");
            Console.WriteLine("Selecione uma opção:");
            Console.WriteLine("1: Cadastrar Novo Cliente");
            Console.WriteLine("2: Abrir Nova Conta (Corrente, Poupança, Especial)");
            Console.WriteLine("3: Realizar Operação (Depósito, Saque, Transferência)");
            Console.WriteLine("4: Exibir Saldos e Total da Agência");
            Console.WriteLine("5: Sair");
            Console.Write("Opção: ");

            string opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1": CadastrarCliente(); break;
                case "2": AbrirConta(); break;
                case "3": RealizarOperacao(); break;
                case "4": ExibirSaldos(); break;
                case "5": sair = true; Console.WriteLine("Encerrando o sistema..."); break;
                default: Console.WriteLine("Opção inválida. Tente novamente."); break;
            }
        }
    }

    private static void CadastrarCliente()
    {
        Console.WriteLine("\n--- CADASTRO DE CLIENTE ---");
        try
        {
            Console.Write("Nome: ");
            string nome = Console.ReadLine();

            Console.Write("Ano de Nascimento (AAAA): ");
            if (!int.TryParse(Console.ReadLine(), out int ano))
            {
                Console.WriteLine("Erro: Ano inválido.");
                return;
            }

            Console.Write("CPF (11 dígitos, apenas números): ");
            string cpf = Console.ReadLine();

            Console.Write("E-mail: ");
            string email = Console.ReadLine();

            // O construtor do Cliente realiza as validações de maioridade e CPF.
            Cliente novoCliente = new Cliente(nome, ano, cpf, email);

            Console.WriteLine("\nSUCESSO: Cliente VALIDADO e pronto para abrir conta!");
            Console.WriteLine(novoCliente);
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"ERRO DE CADASTRO: {ex.Message}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"ERRO INESPERADO: {ex.Message}");
        }
    }

    private static void AbrirConta()
    {
        Console.WriteLine("\n--- ABERTURA DE CONTA ---");
        try
        {
            Console.Write("Tipo de Conta (CC: Corrente, CP: Poupança, CE: Especial): ");
            string tipo = Console.ReadLine().ToUpper();

            // É necessário recriar o cliente para usar o construtor da Conta.
            Console.WriteLine("\n-- Dados do Titular (para vinculação) --");

            Console.Write("Nome Completo do Titular: ");
            string nome = Console.ReadLine();
            Console.Write("Ano de Nascimento (AAAA): ");
            if (!int.TryParse(Console.ReadLine(), out int ano)) return;
            Console.Write("CPF do Titular: ");
            string cpfTitular = Console.ReadLine();
            Console.Write("E-mail do Titular: ");
            string email = Console.ReadLine();
            Cliente titular = new Cliente(nome, ano, cpfTitular, email); // Valida o cliente

            Console.Write("Número da Conta (acima de 999): ");
            if (!long.TryParse(Console.ReadLine(), out long numero))
            {
                Console.WriteLine("Erro: Número da conta inválido.");
                return;
            }

            if (agencia.Contas.Any(c => c.Numero == numero))
            {
                Console.WriteLine("Erro: Já existe uma conta com este número cadastrado.");
                return;
            }

            // Usa CultureInfo.InvariantCulture para aceitar o ponto como separador decimal (500.00)
            Console.Write("Depósito Inicial (use ponto para decimais, ex: 500.00. Se 0, o saldo inicial será R$ 10,00): ");
            if (!decimal.TryParse(Console.ReadLine(), NumberStyles.Currency, CultureInfo.InvariantCulture, out decimal deposito))
            {
                Console.WriteLine("Erro: Valor de depósito inválido.");
                return;
            }

            Conta novaConta = null;

            switch (tipo)
            {
                case "CC":
                    novaConta = new ContaCorrente(titular, numero, deposito);
                    break;
                case "CP":
                    Console.Write("Taxa de Rendimento (ex: 0.05 para 5%): ");
                    if (!float.TryParse(Console.ReadLine(), NumberStyles.Any, CultureInfo.InvariantCulture, out float taxaRendimento)) return;
                    Console.Write("Dia de Aniversário para Rendimento (1 a 31): ");
                    if (!int.TryParse(Console.ReadLine(), out int diaAniversario) || diaAniversario < 1 || diaAniversario > 31)
                    {
                        Console.WriteLine("Dia de aniversário inválido.");
                        return;
                    }
                    novaConta = new ContaPoupanca(titular, numero, taxaRendimento, diaAniversario, deposito);
                    break;
                case "CE":
                    Console.Write("Limite de Crédito para Conta Especial: ");
                    if (!decimal.TryParse(Console.ReadLine(), NumberStyles.Currency, CultureInfo.InvariantCulture, out decimal limite)) return;
                    novaConta = new ContaEspecial(titular, numero, limite, deposito);
                    break;
                default:
                    Console.WriteLine("Tipo de conta inválido.");
                    return;
            }

            if (novaConta != null)
            {
                agencia.InserirConta(novaConta);
                Console.WriteLine($"\nSUCESSO: Conta {tipo} de {titular.Nome} aberta. Saldo inicial: R$ {novaConta.Saldo:F2}.");
            }
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"ERRO AO ABRIR CONTA: {ex.Message}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"ERRO INESPERADO: {ex.Message}");
        }
    }

    private static Conta GetConta(string prompt)
    {
        Console.Write(prompt);
        if (long.TryParse(Console.ReadLine(), out long numero))
        {
            // Busca a conta pelo número
            return agencia.Contas.FirstOrDefault(c => c.Numero == numero);
        }
        return null;
    }

    private static void RealizarOperacao()
    {
        Console.WriteLine("\n--- REALIZAR OPERAÇÃO ---");
        Console.WriteLine("1: Depósito | 2: Saque | 3: Transferência");
        Console.Write("Escolha a operação: ");
        string op = Console.ReadLine();

        if (op != "1" && op != "2" && op != "3")
        {
            Console.WriteLine("Opção de operação inválida.");
            return;
        }

        Conta conta = GetConta("Digite o número da conta de origem: ");
        if (conta == null)
        {
            Console.WriteLine("Conta não encontrada.");
            return;
        }

        Console.Write("Digite o valor da operação (use ponto para decimais): ");
        if (!decimal.TryParse(Console.ReadLine(), NumberStyles.Currency, CultureInfo.InvariantCulture, out decimal valor) || valor <= 0)
        {
            Console.WriteLine("Valor inválido ou negativo.");
            return;
        }

        switch (op)
        {
            case "1":
                conta.Depositar(valor);
                break;
            case "2":
                conta.Sacar(valor);
                break;
            case "3":
                Conta destino = GetConta("Digite o número da conta destino: ");
                if (destino == null)
                {
                    Console.WriteLine("Conta destino não encontrada.");
                    return;
                }
                conta.Transferir(destino, valor);
                break;
        }
        Console.WriteLine($"\n[STATUS ATUAL]: {conta}");
    }

    private static void ExibirSaldos()
    {
        Console.WriteLine("\n--- SALDOS ATUAIS E TOTAL ---");
        if (agencia.Contas.Count == 0)
        {
            Console.WriteLine("Nenhuma conta cadastrada.");
            return;
        }

        foreach (var conta in agencia.Contas)
        {
            Console.WriteLine(conta);
        }

        decimal total = agencia.CalcularTotal();
        Console.WriteLine($"\nTotal Geral de Saldos na Agência ({agencia.Contas.Count} contas): R$ {total:F2}");
    }
}