﻿using System;

public class ContaPoupanca : Conta
{
    public float TaxaRendimento { get; private set; }
    public int DiaAniversario { get; private set; }
    public decimal RendimentoAcumulado { get; private set; }

    public ContaPoupanca(Cliente titular, long numero, float taxaRendimento, int diaAniversario, decimal depositoInicial = 0.00M)
        : base(titular, numero, depositoInicial)
    {
        TaxaRendimento = taxaRendimento;
        DiaAniversario = diaAniversario;
        RendimentoAcumulado = 0.00M;
    }

    public void AplicarRendimento()
    {
        Console.WriteLine($"Rendimento de {TaxaRendimento * 100}% aplicado no dia {DiaAniversario}");
    }

    public override string ToString()
    {
        return $"ContaPoupanca [Numero={Numero}, Saldo={Saldo:F2}, DiaAniversario={DiaAniversario}, Titular={Titular.Nome}]";
    }
}