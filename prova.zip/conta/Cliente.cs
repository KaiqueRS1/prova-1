﻿using System;
using System.Text.RegularExpressions;

public class Cliente
{
    public string Nome { get; private set; }
    https://github.com/KaiqueRS1/prova-1.git
    public int AnoNascimento { get; private set; }
    public string Cpf { get; private set; }
    public string Email { get; private set; }

    public Cliente(string nome, int anoNascimento, string cpf, string email)
    {
        int anoAtual = DateTime.Now.Year;
        if (anoAtual - anoNascimento < 18)
        {
            throw new ArgumentException($"Cliente deve ser maior de 18 anos. Idade atual: {anoAtual - anoNascimento}");
        }

        if (string.IsNullOrEmpty(cpf) || cpf.Length != 11 || !Regex.IsMatch(cpf, @"^\d{11}$"))
        {
            throw new ArgumentException("CPF deve ter exatamente 11 dígitos numéricos.");
        }

        Nome = nome;
        AnoNascimento = anoNascimento;
        Cpf = cpf;
        Email = email;
    }

    public override string ToString()
    {
        return $"Cliente [Nome={Nome}, CPF={Cpf}, Email={Email}]";
    }
}